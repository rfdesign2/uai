# wix-for-free
A free way to remove wix banners and .wixsite url

## How to ?
You just need to open both `.html`files and replace the `WIX-WEBSITE`by your wix url and the `WIX-WEBSITE-NAME` by the name you want to be to be show in the task bar

## What do you need ?

- A computer obviously
- A domain name of your choice
- A web hosting service (could be included to your domain name suscription, look under in the **Contabo** section)


## DISCLAIMER:

This product and source is for educational purpose only. Any damage that is made by use is not our/my fault. To properly remove banners from a WiX.com website, please buy the designated package from the offical website. Thanks!

I decided to publish this source since I have not seen on Github.

NOTE: You could also use a VPS to host your website, along with [Vesta CP](https://github.com/serghey-rodin/vesta). By the way, 

## Contabo 🐶

[Contabo](https://www.anrdoezrs.net/click-100796952-12454703) is the web hoster I recommmand. They are cheap, reliable and have a good support 📒

For example, you could get :
- a private [VPS](https://www.dpbolvw.net/click-100796952-13796470) with 4 vCores, 8GB RAM, 200GB SSD for 5.99€/month 💴
- a [web hosting service](https://www.tkqlhce.com/click-100796952-12454678) with 50GB SSD, 20 MySQL DB, 1 domain and 1000 Email Addresses for 2.99€/month 💶
- a [storage VPS](https://www.anrdoezrs.net/click-100796952-15239531) with 2 vCores, 4GB RAM, 400GB SSD, unlimited bandwitch incoming and 32 TB outcoming for 5.99€/month 💷

> I personnally think that they are the cheapest and the best web hoster in the world 🗺️

Don't hesistate to take a look at their [website](https://www.anrdoezrs.net/click-100796952-12454703) 🌐


